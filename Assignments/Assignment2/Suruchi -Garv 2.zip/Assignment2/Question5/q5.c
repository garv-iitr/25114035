#include<stdio.h>

 int main() {
          if(printf("Hello Wolrd\n")) 
		 return 0;
 }
