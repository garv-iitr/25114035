#include<stdio.h>

int main() {
	printf("Name:Garv \nRoll No:25114035 \nBranch:CSE \n");
	return 0;
}
