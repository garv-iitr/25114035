#include <stdio.h>

int main() {
	printf("Hello World\n");
	printf("\"Hello World\"\n");
	printf("This is a \\n line\n");
	printf("How\tare\tyou\n");
	printf("Bank provides 10%% interest");
	printf("Hello\n\tWorld!\n");
	printf("??!");
	printf("Good /\\ Day!");
	printf("For printing \\n we use \\\\n\n ");
	printf("\"He\"llo wo\"rld\n");
	return 0;
}
