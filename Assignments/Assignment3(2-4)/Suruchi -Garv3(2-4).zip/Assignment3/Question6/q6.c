#include<stdio.h>

int main() {
	char z = 48;
	int a = 1 , b = 12 , c = 123 , d = 1234 , f = 12345 ;

	printf(" %c%c%c%c%d \n",z,z,z,z,a);
	printf(" %c%c%c%d \n",z,z,z,b);
	printf(" %c%c%d \n",z,z,c);
	printf(" %c%d \n",z,d);
	printf(" %d \n",f);
	return 0;
}

	
