#include <stdio.h>
#include <math.h>

int main() {
	double e = 2.718281828 ;
	
	printf(" %0.0lf\n",e);
	printf(" %0.1lf\n",e);
	printf(" %0.2lf\n",e);
	printf(" %0.6lf\n",e);
	printf(" %0.8lf\n",e);
	printf(" %0.9lf\n",e);

	return 0;
}



