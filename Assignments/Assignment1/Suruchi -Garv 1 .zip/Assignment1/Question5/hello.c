#include<stdio.h>

int main() {
	printf("Hello Again.\n");
	return 0;
}
