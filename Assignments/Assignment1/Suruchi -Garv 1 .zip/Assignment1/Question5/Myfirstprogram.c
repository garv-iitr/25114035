#include<stdio.h>

int main() {
	printf("Hello World\n");
	printf("Bingo!!!I learnt to compile and run a C program in Linux!!! I will always use Linux for programming in future\n");
	return 0;
}
